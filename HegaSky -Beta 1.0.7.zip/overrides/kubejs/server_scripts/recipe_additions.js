events.listen('recipes', function(e) {
    //Pipez
    e.shaped('pipez:infinity_upgrade', [
        'ABA',
        'BCB',
        'ABA'
    ], {
        A: 'kubejs:ingot_hega',
        B: 'compressium:redstone_4',
        C: 'pipez:ultimate_upgrade'
    })
    //kubejs
    e.shaped(`kubejs:advanced_steel_casing`, [
        `ABA`,
        `DEF`,
        `GHI`
    ], {
        A: `mekanism:enriched_redstone`,
        B: `mekanism:advanced_control_circuit`,
        D: `mekanism:bio_fuel`,
        E: `mekanism:steel_casing`,
        F: `mekanism:alloy_infused`,
        G: `mekanism:enriched_gold`,
        H: `mekanism:basic_control_circuit`,
        I: `mekanism:enriched_carbon`
    });
    //iron furnace
    e.shaped(`ironfurnaces:netherite_furnace`, [
        `ABA`,
        `BCB`,
        `ADA`
    ], {
        A: `minecraft:netherite_ingot`,
        B: `minecraft:magma_cream`,
        C: `ironfurnaces:obsidian_furnace`,
        D: `excompressum:compressed_hammer_netherite`
    });
    //creative crafter
    e.shaped(`creativecrafter:creative_crafter`, [
        `BUB`,
        `PCP`,
        `BUB`
    ], {
        B: `minecraft:netherite_block`,
        P: `extradisks:withering_processor`,
        C: `extrastorage:netherite_crafter`,
        U: `minecraft:nether_star`
    });
    //mekanism
    e.shaped(`mekanism:metallurgic_infuser`, [
        `BUB`,
        `PCP`,
        `BUB`
    ], {
        B: `minecraft:iron_ingot`,
        P: `minecraft:redstone`,
        C: `mekanism:steel_casing`,
        U: `mekanism:ingot_osmium`
    });    
    //extended craft
    e.shaped(Item.of(`extendedcrafting:black_iron_ingot`, 2), [
        `IL`,
    ], {
        L: `mekanism:ingot_steel`,
        I: `thermal:cured_rubber`
    }); 
    e.custom({
        "type": "extendedcrafting:shaped_table",
        "pattern": [
          "         ",
          "         ",
          "         ",
          "   I I   ",
          "   IOI   ",
          "   AEA   ",
          "         ",
          "         ",
          "         "
        ],
        "key": {
          "I": {
            "item": "cyclic:mason_cobble"
          },
          "O": {
            "item": "ironfurnaces:iron_furnace"
          },
          "E": {
            "item": "kubejs:advanced_steel_casing"
          },
          "A": {
            "item": "kubejs:ingot_hega"
          }
        },
        "result": {
          "item": "bloodmagic:altar"
        }
    })
    e.custom({
        "type": "extendedcrafting:shaped_table",
        "pattern": [
          "         ",
          "         ",
          "         ",
          "   PIP   ",
          "   IOI   ",
          "   PIP   ",
          "         ",
          "         ",
          "         "
        ],
        "key": {
          "I": {
            "item": "mysticalagriculture:inferium_gemstone_block"
          },
          "P": {
            "item": "mysticalagriculture:prosperity_block"
          },
          "O": {
            "item": "bloodmagic:apprenticebloodorb"
          }
        },
        "result": {
          "item": "matc:inferium_crystal"
        }
    })
    e.custom({
      "type": "extendedcrafting:shaped_table",
      "pattern": [
        "         ",
        "         ",
        "         ",
        "   BUB   ",
        "   ECE   ",
        "   BUB   ",
        "         ",
        "         ",
        "         "
      ],
      "key": {
        "B": {
          "item": "mekanism:ingot_steel"
        },
        "C": {
          "item": "kubejs:advanced_steel_casing"
        },
        "U": {
          "item": "kubejs:ingot_gera"
        },
        "E": {
          "item": "extendedcrafting:black_iron_nugget"
        }
      },
      "result": {
        "item": "rftoolsbase:machine_frame"
      }
  })
  e.custom({
    "type": "extendedcrafting:shaped_table",
    "pattern": [
      "         ",
      "         ",
      "    D    ",
      "   BAB   ",
      "  DACAD  ",
      "   BAB   ",
      "    D    ",
      "         ",
      "         "
    ],
    "key": {
      "A": {
        "item": "minecraft:brick"
      },
      "B": {
        "item": "minecraft:clay_ball"
      },
      "C": {
        "item": "minecraft:sandstone"
      },
      "D": {
        "item": "botania:manasteel_ingot"
      }
      },
    "result": {
      "item": "immersiveengineering:cokebrick",
      "count": 3
    }
  })
    e.custom({
      "type": "extendedcrafting:shaped_table",
      "pattern": [
       " A  B  A ",
       "  ABABC  ",
       " CBCCCBA ",
       " BCCCACB ",
       "  BBBBB  ",
       "         ",
       "         "
    ],
    "key": {
      "A": {
        "item": "fluxnetworks:flux_dust"
      },
      "B": {
        "item": "immersiveengineering:dust_hop_graphite"
      },
      "C": {
        "item": "mekanism:dust_netherite"
      }
      },
    "result": {
      "item": "kubejs:blacked_dust",
      "count": 5
    }
  })
    e.custom({
      "type": "extendedcrafting:shaped_table",
      "pattern": [
       "  ABA  ",
       " ACDCA ",
       " EDFDE ",
       " ACDCA ",
       "  ABA  "
    ],
    "key": {
      "A": {
        "item": "immersiveengineering:ingot_hop_graphite"
      },
      "B": {
        "item": "botania:terrasteel_ingot"
      },
      "C": {
        "item": "industrialforegoing:plastic"
      },
      "D": {
        "item": "matc:inferium_crystal",
      },
      "E": {
        "item": "mekanism:elite_control_circuit"
      },
      "F": {
        "item": "bloodmagic:magicianbloodorb"
      }
      },
    "result": {
      "item": "matc:prudentium_crystal"
    }
  })
    e.custom({
      "type": "extendedcrafting:shaped_table",
      "pattern": [
       " ABCBA ",
       " DEFED ",
       " GFHFG ",
       " DEFED ",
       " ABCBA "
    ],
    "key": {
      "A": {
        "item": "botania:terrasteel_ingot"
      },
      "B": {
        "item": "industrialforegoing:machine_frame_pity"
      },
      "C": {
        "item": "mekanism:elite_control_circuit"
      },
      "D": {
        "item": "mysticalagriculture:tertium_block"
      },
      "E": {
        "item": "immersiveengineering:ingot_hop_graphite"
      },
      "F": {
        "item": "refinedstorage:machine_casing"
      },
      "G": {
        "item": "extendedcrafting:advanced_component"
      },
      "H": {
        "item": "kubejs:elite_steel_casing"
      }
      },
    "result": {
      "item": "kubejs:ultimate_steel_casing"
    }
  })
    e.custom({
      "type": "extendedcrafting:shaped_table",
      "pattern": [
       "   A   ",
       "  BCB  ",
       " BDEDB ",
       "ACEFECA",
       " BDEDB ",
       "  BCB  ",
       "   A   "
    ],
    "key": {
      "A": {
        "item": "botania:dragonstone"
      },
      "B": {
        "item": "extendedcrafting:elite_component"
      },
      "C": {
        "item": "industrialforegoing:machine_frame_supreme"
      },
      "D": {
        "item": "mekanism:alloy_atomic"
      },
      "E": {
        "item": "bloodmagic:demonslate"
      },
      "F": {
        "item": "matc:prudentium_crystal",
      }
      },
    "result": {
      "item": "matc:tertium_crystal"
    }
  })
    e.custom({
      "type": "extendedcrafting:shaped_table",
      "pattern": [
       "ABCDCBA",
       "BEFGFEB",
       "CFHIHFC",
       "DGIJIGD",
       "CFHIHFC",
       "BEFGFEB",
       "ABCDCBA"
    ],
    "key": {
      "A": {
        "item": "botania:life_essence"
      },
      "B": {
        "item": "industrialforegoing:machine_frame_supreme"
      },
      "C": {
        "item": "extendedcrafting:elite_catalyst"
      },
      "D": {
        "item": "botania:gaia_ingot"
      },
      "E": {
        "item": "botania:pixie_dust"
      },
      "F": {
        "item": "mysticalagriculture:imperium_block"
      },
      "G": {
        "item": "mekanism:alloy_atomic"
      },
      "H": {
        "item": "mekanism:ultimate_control_circuit"
      },
      "I": {
        "item": "bloodmagic:demonslate"
      },
      "J": {
        "item": "kubejs:ultimate_steel_casing"
      }
      },
    "result": {
      "item": "kubejs:legendary_steel_casing"
    }
  })
    e.custom({
      "type": "extendedcrafting:shaped_table",
      "pattern": [
       "    A    ",
       "   ABA   ",
       "   ABA   ",
       " AAABAAA ",
       "ABBBCBBBA",
       " AAABAAA ",
       "   ABA   ",
       "   ABA   ",
       "    A    "
    ],
    "key": {
      "A": {
        "item": "mysticalagriculture:imperium_essence"
      },
      "B": {
        "item": "mysticalagriculture:imperium_block"
      },
      "C": {
        "item": "matc:tertium_crystal"
      }
      },
    "result": {
      "item": "matc:imperium_crystal"
    }
  })
    e.custom({ 
      "type": "extendedcrafting:shaped_table",
      "pattern": [
       "ABBCCCBBA",
       "BDDDDDDDB",
       "BDEEEEEDB",
       "CDEEFEEDC",
       "CDEFGFEDC",
       "CDEEFEEDC",
       "BDEEEEEDB",
       "BDDDDDDDB",
       "ABBCCCBBA"
    ],
    "key": {
      "A": {
        "item": "extendedcrafting:black_iron_block"
      },
      "B": {
        "item": "extendedcrafting:black_iron_ingot"
      },
      "C": {
        "item": "extendedcrafting:ender_component"
      },
      "D": {
        "item": "extendedcrafting:black_iron_slate"
      },
      "E": {
        "item": "minecraft:glass"
      },
      "F": {
        "item": "extendedcrafting:enhanced_ender_catalyst"
      },
      "G": {
        "item": "extendedcrafting:frame"
      }
      },
    "result": {
      "item": "extendedcrafting:compressor"
    }
  })
    e.custom({ 
      "type": "extendedcrafting:shaped_table",
      "pattern": [
       " A B A   ",
       "A    C  A",
       " D EEE F ",
       "  EGBGE  ",
       "CEGAHDGEC",
       "CEBHIHBEC",
       "GEGDHAGEG",
       " JEGBGEJ ",
       "   EEE   "
    ],
    "key": {
      "A": {
        "item": "industrialforegoing:pink_slime_ingot"
      },
      "B": {
        "item": "botania:dragonstone"
      },
      "C": {
        "item": "botania:elementium_ingot"
      },
      "D": {
        "item": "bloodmagic:weakbloodshard"
      },
      "E": {
        "item": "powah:crystal_nitro"
      },
      "F": {
        "item": "botania:pixie_dust"
      },
      "G": {
        "item": "mekanism:ultimate_control_circuit"
      },
      "H": {
        "item": "kubejs:legendary_steel_casing"
      },
      "I": {
        "item": "extendedcrafting:ultimate_singularity"
      },
      "J": {
        "item": "tconstruct:rose_gold_ingot"
      }
      },
    "result": {
      "item": "projecte:philosophers_stone"
    }
  })
    e.custom({ 
      "type": "extendedcrafting:shaped_table",
      "pattern": [
       "ABBABBA",
       "BCCCCCB",
       "BCDDDCB",
       "ACDEDCA",
       "BCDDDCB",
       "BCCCCCB",
       "ABBABBA"
    ],
    "key": {
      "A": {
        "item": "mysticalagradditions:insanium_essence"
      },
      "B": {
        "item": "mysticalagradditions:insanium_gemstone"
      },
      "C": {
        "item": "compressium:stone_3"
      },
      "D": {
        "item": "projecte:dark_matter"
      },
      "E": {
        "item": "projecte:philosophers_stone"
      }
      },
    "result": {
      "item": "projecte:transmutation_table"
    }
  })
    e.custom({ 
        "type": "extendedcrafting:shaped_table",
        "pattern": [
          "ABCDEFGHI",
          "JKLMNOPQR",
          "STUVWXYZ1",
          "2345     ",
          "         ",
          "         ",
          "         ",
          "         ",
          "         "
        ],
        "key": {
          "A": {
            "item": "twilightforest:knightmetal_ingot"
          },
          "B": {
            "item": "tconstruct:manyullyn_ingot"
          },
          "C": {
            "item": "mekanism:ingot_refined_obsidian"
          },
          "D": {
            "item": "botania:elementium_ingot"
          },
          "E": {
            "item": "industrialforegoing:pink_slime_ingot"
          },
          "F": {
            "item": "immersiveengineering:ingot_constantan"
          },
          "G": {
            "item": "thermal:signalum_ingot"
          },
          "H": {
            "item": "mysticalagriculture:tertium_ingot"
          },
          "I": {
            "item": "immersiveengineering:ingot_electrum"
          },
          "J": {
            "item": "mekanism:ingot_copper"
          },
          "K": {
            "item": "mekanism:ingot_bronze"
          },
          "L": {
            "item": "thermal:nickel_ingot"
          },
          "M": {
            "item": "minecraft:gold_ingot"
          },
          "N": {
            "item": "thermal:lumium_ingot"
          },
          "O": {
            "item": "mekanism:ingot_refined_glowstone"
          },
          "P": {
            "item": "mekanism:ingot_uranium"
          },
          "Q": {
            "item": "botania:terrasteel_ingot"
          },
          "R": {
            "item": "avaritia:crystal_matrix_ingot"
          },
          "S": {
            "item": "extendedcrafting:crystaltine_ingot"
          },
          "T": {
            "item": "botania:manasteel_ingot"
          },
          "U": {
            "item": "thermal:enderium_ingot"
          },
          "V": {
            "item": "thermal:lead_ingot"
          },
          "W": {
            "item": "thermal:silver_ingot"
          },
          "X": {
            "item": "thermal:tin_ingot"
          },
          "Y": {
            "item": "mekanism:ingot_osmium"
          },
          "Z": {
            "item": "mysticalagriculture:prosperity_ingot"
          },
          "1": {
            "item": "minecraft:iron_ingot"
          },
          "2": {
            "item": "immersiveengineering:ingot_aluminum"
          },
          "3": {
            "item": "botania:gaia_ingot"
          },
          "4": {
            "item": "extendedcrafting:black_iron_ingot"
          },
          "5": {
            "item": "avaritia:neutronium_ingot"
          }
        },
        "result": {
          "item": "extendedcrafting:the_ultimate_ingot"
        }
      })
    e.custom({ 

        "type": "extendedcrafting:shaped_table",
        "pattern": [
          "AAAAAAA",
          "AAAAAAA",
          "BBCCCBB",
          "BBCDCBB",
          "BBCCCBB",
          "AAAAAAA",
          "AAAAAAA"
        ],
        "key": {
          "A": {
            "item": "minecraft:iron_block"
          },
          "B": {
            "item": "extendedcrafting:redstone_ingot_block"
          },
          "C": {
            "item": "projecte:dark_matter"
          },
          "D": {
            "item": "extendedcrafting:frame"
          }
        },
        "result": {
          "item": "avaritia:neutron_collector"
        }
    })
    e.custom({ 
        "type": "extendedcrafting:shaped_table",
        "pattern": [
          "    A    ",
          "   ABA   ",
          "   ACA   ",
          " AADBEAA ",
          "ABCBFBCBA",
          " AAGBHAA ",
          "   ACA   ",
          "   ABA   ",
          "    A    "
        ],
        "key": {
          "A": {
            "item": "avaritia:neutronium_ingot"
          },
          "B": {
            "item": "extendedcrafting:the_ultimate_ingot"
          },
          "C": {
            "item": "avaritia:crystal_matrix_ingot"
          },
          "D": {
            "item": "avaritia:record_fragment"
          },
          "E": {
            "item": "avaritia:cosmic_meatballs"
          },
          "F": {
            "item": "extendedcrafting:ultimate_singularity"
          },
          "G": {
            "item": "avaritia:ultimate_stew"
          },
          "H": {
            "item": "avaritia:endest_pearl"
          }
        },
        "result": {
          "item": "avaritia:infinity_catalyst"
      }
    })
    e.custom({ 
        "type": "extendedcrafting:shaped_table",
        "pattern": [
          "ABCDEFG",
          "HIJKLMN",
          "OPQRSTU",
          "VWX    ",
          "       ",
          "       ",
          "       "
        ],
        "key": {
          "A": {
            "item": "minecraft:potato"
          },
          "B": {
            "item": "minecraft:sweet_berries"
          },
          "C": {
            "item": "minecraft:beetroot"
          },
          "D": {
            "item": "minecraft:apple"
          },
          "E": {
            "item": "minecraft:carrot"
          },
          "F": {
            "item": "minecraft:honeycomb"
          },
          "G": {
            "item": "mysticalagradditions:insanium_apple"
          },
          "H": {
            "item": "thermal:barley"
          },
          "I": {
            "item": "thermal:corn"
          },
          "J": {
            "item": "thermal:flax"
          },
          "K": {
            "item": "thermal:onion"
          },
          "L": {
            "item": "thermal:radish"
          },
          "M": {
            "item": "thermal:rice"
          },
          "N": {
            "item": "thermal:sadiroot"
          },
          "O": {
            "item": "thermal:spinach"
          },
          "P": {
            "item": "thermal:bell_pepper"
          },
          "Q": {
            "item": "thermal:eggplant"
          },
          "R": {
            "item": "thermal:green_bean"
          },
          "S": {
            "item": "thermal:peanut"
          },
          "T": {
            "item": "thermal:strawberry"
          },
          "U": {
            "item": "thermal:tomato"
          },
          "V": {
            "item": "thermal:coffee"
          },
          "W": {
            "item": "thermal:tea"
          },
          "X": {
            "item": "avaritia:neutronium_ingot"
          }
        },
        "result": {
          "item": "avaritia:cosmic_meatballs"
        }
      })
    e.custom({ 
        "type": "extendedcrafting:shaped_table",
        "pattern": [
          "ABCDEFG",
          "HIJKLMN",
          "OPQ    ",
          "       ",
          "       ",
          "       ",
          "       "
        ],
        "key": {
          "A": {
            "item": "minecraft:cooked_chicken"
          },
          "B": {
            "item": "minecraft:chicken"
          },
          "C": {
            "item": "minecraft:cooked_beef"
          },
          "D": {
            "item": "minecraft:beef"
          },
          "E": {
            "item": "minecraft:cooked_cod"
          },
          "F": {
            "item": "minecraft:cooked_salmon"
          },
          "G": {
            "item": "minecraft:tropical_fish"
          },
          "H": {
            "item": "minecraft:pufferfish"
          },
          "I": {
            "item": "minecraft:salmon"
          },
          "J": {
            "item": "minecraft:cod"
          },
          "K": {
            "item": "minecraft:porkchop"
          },
          "L": {
            "item": "minecraft:cooked_porkchop"
          },
          "M": {
            "item": "minecraft:mutton"
          },
          "N": {
            "item": "minecraft:cooked_mutton"
          },
          "O": {
            "item": "minecraft:rabbit"
          },
          "P": {
            "item": "minecraft:cooked_rabbit"
          },
          "Q": {
            "item": "avaritia:neutronium_ingot"
          }
        },
        "result": {
          "item": "avaritia:ultimate_stew"
        }
      })
    e.custom({ 
        "type": "extendedcrafting:shaped_table",
        "pattern": [
          "   AAA   ",
          " AABBBAA ",
          " ABBBBBA ",
          "ABBBCBBBA",
          "ABBCDCBBA",
          "ABBBCBBBA",
          " ABBBBBA ",
          " AABBBAA ",
          "   AAA   "
        ],
        "key": {
          "A": {
            "item": "avaritia:crystal_matrix_ingot"
          },
          "B": {
            "item": "minecraft:ender_pearl"
          },
          "C": {
            "item": "avaritia:neutronium_ingot"
          },
          "D": {
            "item": "extendedcrafting:ender_star"
          }
        },
        "result": {
          "item": "avaritia:endest_pearl"
        }
      })
    e.custom({ 
        "type": "extendedcrafting:shaped_table",
        "pattern": [
          "AAAAAAAAA",
          "ABCCBCCBA",
          "ACDBCBDCA",
          "ABCCBCCBA",
          "AAAAAAAAA",
          "         ",
          "         ",
          "         ",
          "         "
        ],
        "key": {
          "A": {
            "item": "avaritia:neutronium_ingot"
          },
          "B": {
            "item": "extendedcrafting:the_ultimate_ingot"
          },
          "C": {
            "item": "avaritia:infinity_catalyst"
          },
          "D": {
            "item": "avaritia:crystal_matrix_ingot"
          }
        },
        "result": {
          "item": "avaritia:infinity_ingot"
        }
      })
    e.custom({ 
        "type": "extendedcrafting:shaped_table",
        "pattern": [
          "       AA",
          "      ABA",
          "     ACA ",
          "    ADA  ",
          " E AFA   ",
          "  EGA    ",
          "  HE     ",
          " H  E    ",
          "I        "
        ],
        "key": {
          "A": {
            "item": "avaritia:infinity_ingot"
          },
          "B": {
            "type": "forge:nbt",
            "item": "mahoutsukai:morgan",
            "count": 1,
            "nbt": "{Damage:0}"
          },
          "C": {
            "item": "projecte:rm_sword"
          },
          "D": {
            "type": "forge:nbt",
            "item": "cyclic:crystal_sword",
            "count": 1,
            "nbt": "{Damage:0}"
          },
          "E": {
            "item": "avaritia:crystal_matrix_ingot"
          },
          "F": {
            "item": "mysticaladaptations:insanium_sword"
          },
          "G": {
            "item": "extendedcrafting:ultimate_singularity"
          },
          "H": {
            "item": "avaritia:neutronium_ingot"
          },
          "I": {
            "item": "avaritia:infinity_catalyst"
          }
        },
        "result": {
          "item": "avaritia:swordofthe_cosmos"
        }
      })
    e.custom({ 
        "type": "extendedcrafting:shaped_table",
        "pattern": [
          " AAAAAAA ",
          "AAAABAAAA",
          "AAC D CAA",
          "A   D   A",
          "    D    ",
          "    D    ",
          "    D    ",
          "    D    ",
          "    E    "
        ],
        "key": {
          "A": {
            "item": "avaritia:infinity_ingot"
          },
          "B": {
            "item": "avaritia:crystal_matrix"
          },
          "C": {
            "item": "extendedcrafting:ultimate_singularity"
          },
          "D": {
            "item": "avaritia:neutronium_ingot"
          },
          "E": {
            "item": "avaritia:infinity_catalyst"
          }
        },
        "result": {
          "item": "avaritia:world_breaker"
        }
      })
    e.custom({ 
        "type": "extendedcrafting:shaped_table",
        "pattern": [
          "   AA    ",
          "  A B    ",
          " A  B    ",
          "A   B    ",
          "C   B    ",
          "A   B    ",
          " A  B    ",
          "  A B    ",
          "   AA    "
        ],
        "key": {
          "A": {
            "item": "avaritia:infinity_ingot"
          },
          "B": {
            "item": "minecraft:white_wool"
          },
          "C": {
            "item": "avaritia:infinity_catalyst"
          }
        },
        "result": {
          "item": "avaritia:longbowofthe_heavens"
        }
      })
      e.custom({
          "type": "extendedcrafting:shaped_table",
          "pattern": [
            "      AAA",
            "     BACA",
            "      AAA",
            "     D B ",
            "    D    ",
            "   D     ",
            "  D      ",
            " D       ",
            "E        "
          ],
          "key": {
            "A": {
              "item": "avaritia:infinity_ingot"
            },
            "B": {
              "item": "extendedcrafting:ultimate_singularity"
            },
            "C": {
              "item": "avaritia:infinity_block"
            },
            "D": {
              "item": "avaritia:neutronium_ingot"
            },
            "E": {
              "item": "avaritia:infinity_catalyst"
            }
          },
          "result": {
            "item": "avaritia:planet_eater"
          }
        })
      e.custom({
          "type": "extendedcrafting:shaped_table",
          "pattern": [
            " A       ",
            "AAAAA    ",
            "AAAA     ",
            " AB      ",
            "  B      ",
            "  B      ",
            "  B      ",
            "  B      ",
            "  C      "
          ],
          "key": {
            "A": {
              "item": "avaritia:infinity_ingot"
            },
            "B": {
              "item": "avaritia:neutronium_ingot"
            },
            "C": {
              "item": "avaritia:infinity_catalyst"
            }
          },
          "result": {
            "item": "avaritia:natures_ruin"
          }
        })
      e.custom({
          "type": "extendedcrafting:shaped_table",
          "pattern": [
            "   AA    ",
            " AAAAAA  ",
            "  AAAAAA ",
            "     BAA ",
            "    B    ",
            "   B     ",
            "  B      ",
            " B       ",
            "C        "
          ],
          "key": {
            "A": {
              "item": "avaritia:infinity_ingot"
            },
            "B": {
              "item": "avaritia:neutronium_ingot"
            },
            "C": {
              "item": "avaritia:infinity_catalyst"
            }
          },
          "result": {
            "item": "avaritia:hoeofthe_green_earth"
          }
        })
      e.custom({
          "type": "extendedcrafting:shaped_table",
          "pattern": [
            "  AAAAA  ",
            " ABBBBBA ",
            " ABCDCBA ",
            " ABBEBBA ",
            " ABFBFBA ",
            " AB B BA ",
            "         ",
            "         ",
            "         "
          ],
          "key": {
            "A": {
              "item": "avaritia:neutronium_ingot"
            },
            "B": {
              "item": "avaritia:infinity_ingot"
            },
            "C": {
              "item": "avaritia:infinity_catalyst"
            },
            "D": {
              "type": "forge:nbt",
              "item": "mekanism:mekasuit_helmet",
              "count": 1,
              "nbt": "{HideFlags:2}"
            },
            "E": {
              "type": "forge:nbt",
              "item": "mysticaladaptations:insanium_helmet",
              "count": 1,
              "nbt": "{Damage:0}"
            },
            "F": {
              "item": "extendedcrafting:ultimate_singularity"
            }
          },
          "result": {
            "item": "avaritia:infinity_armor_helmet"
          }
        })
        e.custom({
            "type": "extendedcrafting:shaped_table",
            "pattern": [
              " AA   AA ",
              "ABA   ABA",
              "AAA   AAA",
              " ACCCCCA ",
              " ACCDCCA ",
              " ACCECCA ",
              " ACCCCCA ",
              " ACCCCCA ",
              "  AAAAA  "
            ],
            "key": {
              "A": {
                "item": "avaritia:neutronium_ingot"
              },
              "B": {
                "item": "extendedcrafting:ultimate_singularity"
              },
              "C": {
                "item": "avaritia:infinity_ingot"
              },
              "D": {
                "type": "forge:nbt",
                "item": "mekanism:mekasuit_bodyarmor",
                "count": 1,
                "nbt": "{HideFlags:2}"
              },
              "E": {
                "type": "forge:nbt",
                "item": "mysticaladaptations:insanium_chestplate",
                "count": 1,
                "nbt": "{Damage:0}"
              }
            },
            "result": {
              "item": "avaritia:infinity_armor_chestplate"
            }
          })
  e.custom({
            "type": "extendedcrafting:shaped_table",
            "pattern": [
              "AAAAAAAAA",
              "ABBBCBBBA",
              "ABAADAABA",
              "ABA   ABA",
              "AEA   AEA",
              "ABA   ABA",
              "ABA   ABA",
              "ABA   ABA",
              "AAA   AAA"
            ],
            "key": {
              "A": {
                "item": "avaritia:neutronium_ingot"
              },
              "B": {
                "item": "avaritia:infinity_ingot"
              },
              "C": {
                "type": "forge:nbt",
                "item": "mekanism:mekasuit_pants",
                "count": 1,
                "nbt": "{HideFlags:2}"
              },
              "D": {
                "type": "forge:nbt",
                "item": "mysticaladaptations:insanium_leggings",
                "count": 1,
                "nbt": "{Damage:0}"
              },
              "E": {
                "item": "extendedcrafting:ultimate_singularity"
              }
            },
            "result": {
              "item": "avaritia:infinity_armor_leggings"
            }
          })
    e.custom({
        "type": "extendedcrafting:shaped_table",
        "pattern": [
          " AAA AAA ",
          " ABA ABA ",
          " ABC DBA ",
          "AABA ABAA",
          "AEBA ABEA",
          "AAAA AAAA",
          "         ",
          "         ",
          "         "
        ],
        "key": {
          "A": {
            "item": "avaritia:neutronium_ingot"
          },
          "B": {
            "item": "avaritia:infinity_ingot"
          },
          "C": {
            "type": "forge:nbt",
            "item": "mysticaladaptations:insanium_boots",
            "count": 1,
            "nbt": "{Damage:0}"
          },
          "D": {
            "type": "forge:nbt",
            "item": "mekanism:mekasuit_boots",
            "count": 1,
            "nbt": "{HideFlags:2}"
          },
          "E": {
            "item": "extendedcrafting:ultimate_singularity"
          }
        },
        "result": {
          "item": "avaritia:infinity_armor_boots"
        }
      })
    e.custom({
        "type": "extendedcrafting:shaped_table",
        "pattern": [
          "ABCBBBCBA",
          "BDEFGFEDB",
          "CEFHIHFEC",
          "BFHIJIHFB",
          "BGIJKJIGB",
          "BFHIJIHFB",
          "CEFHIHFEC",
          "BDEFGFEDB",
          "ABCBBBCBA"
        ],
        "key": {
          "A": {
            "item": "extendedcrafting:ultimate_singularity"
          },
          "B": {
            "item": "appliedenergistics2:singularity"
          },
          "C": {
            "item": "mysticalagradditions:creative_essence"
          },
          "D": {
            "item": "mekanism:pellet_antimatter"
          },
          "E": {
            "item": "projecte:red_matter"
          },
          "F": {
            "item": "avaritia:neutronium_ingot"
          },
          "G": {
            "item": "powah:crystal_nitro"
          },
          "H": {
            "item": "mekanism:pellet_plutonium"
          },
          "I": {
            "item": "avaritia:infinity_catalyst"
          },
          "J": {
            "item": "extendedcrafting:the_ultimate_catalyst"
          },
          "K": {
            "item": "kubejs:legendary_steel_casing"
          }
        },
        "result": {
          "item": "kubejs:creative_steel_casing"
        }
      })
    e.custom({
        "type": "extendedcrafting:shaped_table",
        "pattern": [
          "ABCCDCCBA",
          "BEFFGFFEB",
          "CFHHHHHFC",
          "CFHHHHHFC",
          "DGHHIHHGD",
          "CFHHHHHFC",
          "CFHHHHHFC",
          "BEFFGFFEB",
          "ABCCDCCBA"
        ],
        "key": {
          "A": {
            "item": "appliedenergistics2:singularity"
          },
          "B": {
            "item": "powah:crystal_nitro"
          },
          "C": {
            "item": "mekanism:pellet_polonium"
          },
          "D": {
            "item": "extendedcrafting:the_ultimate_catalyst"
          },
          "E": {
            "item": "avaritia:infinity_catalyst"
          },
          "F": {
            "item": "avaritia:neutronium_ingot"
          },
          "G": {
            "item": "projecte:red_matter"
          },
          "H": {
            "item": "waterstrainer:worm"
          },
          "I": {
            "item": "kubejs:creative_steel_casing"
          }
        },
        "result": {
          "item": "waterstrainer:super_worm"
        }
      })
    e.custom({
        "type": "extendedcrafting:shaped_table",
        "pattern": [
          "AAAAAAAAA",
          "ABCDEDCBA",
          "ACFGFGFCA",
          "ADGFHFGDA",
          "AEFIJKFEA",
          "ADGFLFGDA",
          "ACFGFGFCA",
          "ABCDEDCBA",
          "AAAAAAAAA"
        ],
        "key": {
          "A": {
            "item": "avaritia:neutronium_ingot"
          },
          "B": {
            "item": "waterstrainer:super_worm"
          },
          "C": {
            "item": "extendedcrafting:the_ultimate_catalyst"
          },
          "D": {
            "item": "mysticalagradditions:creative_essence"
          },
          "E": {
            "item": "powah:crystal_nitro"
          },
          "F": {
            "item": "projecte:red_matter"
          },
          "G": {
            "item": "avaritia:infinity_catalyst"
          },
          "H": {
            "item": "tconstruct:ichor_slime_crystal"
          },
          "I": {
            "item": "tconstruct:sky_slime_crystal"
          },
          "J": {
            "item": "kubejs:creative_steel_casing"
          },
          "K": {
            "item": "tconstruct:earth_slime_crystal"
          },
          "L": {
            "item": "tconstruct:ender_slime_crystal"
          }
        },
        "result": {             
          "type": "forge:nbt",
          "item": "tconstruct:creative_slot",
          "count": 1,
          "nbt": "{slot:\"upgrades\"}"
        }
      })
    e.custom({
        "type": "extendedcrafting:shaped_table",
        "pattern": [
          "AAAAAAAAA",
          "ABCDEDCBA",
          "ACFGFGFCA",
          "ADGFHFGDA",
          "AEFIJIFEA",
          "ADGFHFGDA",
          "ACFGFGFCA",
          "ABCDEDCBA",
          "AAAAAAAAA"
        ],
        "key": {
          "A": {
            "item": "avaritia:neutronium_ingot"
          },
          "B": {
            "item": "waterstrainer:super_worm"
          },
          "C": {
            "item": "extendedcrafting:the_ultimate_catalyst"
          },
          "D": {
            "item": "mysticalagradditions:creative_essence"
          },
          "E": {
            "item": "powah:crystal_nitro"
          },
          "F": {
            "item": "projecte:red_matter"
          },
          "G": {
            "item": "avaritia:infinity_catalyst"
          },
          "H": {
            "item": "tconstruct:iron_reinforcement"
          },
          "I": {
            "item": "tconstruct:slimesteel_reinforcement"
          },
          "J": {
            "item": "kubejs:creative_steel_casing"
          }
        },
        "result": {
          "type": "forge:nbt",
          "item": "tconstruct:creative_slot",
          "count": 1,
          "nbt": "{slot:\"abilities\"}"
        }
      })
    e.custom({
        "type": "extendedcrafting:shaped_table",
        "pattern": [
          "ABBBBBBBA",
          "AAAAAAAAA",
          "CDEFGFHDC",
          "CDIFGFIDC",
          "CDIJGKIDC",
          "CDIFGFIDC",
          "CDEFGFHDC",
          "AAAAAAAAA",
          "ABBBBBBBA"
        ],
        "key": {
          "A": {
            "item": "apotheosis:pearl_endshelf"
          },
          "B": {
            "item": "powah:crystal_nitro"
          },
          "C": {
            "item": "storagedrawers:upgrade_template"
          },
          "D": {
            "item": "storagedrawers:iron_storage_upgrade"
          },
          "E": {
            "item": "extradisks:65536k_storage_part"
          },
          "F": {
            "item": "storagedrawers:diamond_storage_upgrade"
          },
          "G": {
            "item": "storagedrawers:gold_storage_upgrade"
          },
          "H": {
            "item": "ae2extras:16m_cell_component"
          },
          "I": {
            "item": "storagedrawers:emerald_storage_upgrade"
          },
          "J": {
            "type": "forge:nbt",
            "item": "tconstruct:creative_slot",
            "count": 1,
            "nbt": "{slot:\"abilities\"}"
          },
          "K": {
            "type": "forge:nbt",
            "item": "tconstruct:creative_slot",
            "count": 1,
            "nbt": "{slot:\"upgrades\"}"
          }
        },
        "result": {
          "item": "storagedrawers:creative_storage_upgrade"
        }
      })
    e.custom({
        "type": "extendedcrafting:shaped_table",
        "pattern": [
          "  AAAAA  ",
          " BCCCCCB ",
          "ACDDDDDCA",
          "ACDEFEDCA",
          "ACDFGFDCA",
          "ACDEFEDCA",
          "ACDDDDDCA",
          " BCCCCCB ",
          "  AAAAA  "
        ],
        "key": {
          "A": {
            "item": "powah:crystal_nitro"
          },
          "B": {
            "item": "bloodmagic:activationcrystalweak"
          },
          "C": {
            "item": "extendedcrafting:ultimate_singularity"
          },
          "D": {
            "item": "mekanism:pellet_polonium"
          },
          "E": {
            "item": "mysticalagradditions:creative_essence"
          },
          "F": {
            "item": "extendedcrafting:the_ultimate_catalyst"
          },
          "G": {
            "item": "kubejs:creative_steel_casing"
          }
        },
        "result": {
          "item": "bloodmagic:activationcrystalcreative"
        }
      })
    e.custom({
        "type": "extendedcrafting:shaped_table",
        "pattern": [
          "  AAAAA  ",
          " BCCDCCB ",
          "ACEEEEECA",
          "ACEFFFECA",
          "ADEFGFEDA",
          "ACEFFFECA",
          "ACEEEEECA",
          " BCCDCCB ",
          "  AAAAA  "
        ],
        "key": {
          "A": {
            "item": "powah:crystal_nitro"
          },
          "B": {
            "item": "buildinggadgets:construction_paste_container_t3"
          },
          "C": {
            "item": "extendedcrafting:ultimate_singularity"
          },
          "D": {
            "item": "mekanism:pellet_polonium"
          },
          "E": {
            "item": "mekanismgenerators:reactor_glass"
          },
          "F": {
            "item": "mysticalagradditions:creative_essence"
          },
          "G": {
            "item": "bloodmagic:activationcrystalcreative"
          }
        },
        "result": {
          "item": "buildinggadgets:construction_paste_container_creative"
        }
      })
    e.custom({
        "type": "extendedcrafting:shaped_table",
        "pattern": [
          "AABBBBBAA",
          "AABCDCBAA",
          "BBBCDCBBB",
          "BCCCDCCCB",
          "BDDDEDDDB",
          "BCCCDCCCB",
          "BBBCDCBBB",
          "AABCDCBAA",
          "AABBBBBAA"
        ],
        "key": {
          "A": {
            "item": "powah:crystal_nitro"
          },
          "B": {
            "type": "forge:nbt",
            "item": "ironjetpacks:emerald_jetpack",
            "count": 1,
            "nbt": "{Throttle:1.0d}"
          },
          "C": {
            "item": "avaritia:neutronium_ingot"
          },
          "D": {
            "item": "extendedcrafting:the_ultimate_catalyst"
          },
          "E": {
            "item": "buildinggadgets:construction_paste_container_creative"
          }
        },
        "result": {
          "item": "ironjetpacks:creative_jetpack"
        }
      })
    e.custom({

        "type": "extendedcrafting:shaped_table",
        "pattern": [
          "AAAAAAAAA",
          "ABBBBBBBA",
          "ABCCCCCBA",
          "ABCDDDCBA",
          "AECFGFCHA",
          "ABCDDDCBA",
          "ABCCCCCBA",
          "ABBBBBBBA",
          "AAAAAAAAA"
        ],
        "key": {
          "A": {
            "item": "create:chromatic_compound"
          },
          "B": {
            "item": "botania:crafty_crate"
          },
          "C": {
            "item": "create:refined_radiance"
          },
          "D": {
            "item": "create:shadow_steel"
          },
          "E": {
            "item": "projecte:tome"
          },
          "F": {
            "item": "create:adjustable_crate"
          },
          "G": {
            "item": "auxilium:blue_matter"
          },
          "H": {
            "type": "forge:nbt",
            "item": "botania:mana_tablet",
            "count": 1,
            "nbt": "{mana:500000,creative:1b}"
          }
        },
        "result": {
          "item": "create:creative_crate"

      }
      })
    e.custom({
        "type": "extendedcrafting:shaped_table",
        "pattern": [
          "ABBBBBBBA",
          "CDDDDDDDC",
          "CDEFFFEDC",
          "CDFGGGFDC",
          "CDFGHGFDC",
          "CDFGGGFDC",
          "CDEFFFEDC",
          "CDDDDDDDC",
          "ABBBBBBBA"
        ],
        "key": {
          "A": {
            "item": "avaritia:infinity_catalyst"
          },
          "B": {
            "item": "extendedcrafting:ultimate_singularity"
          },
          "C": {
            "item": "projecte:red_matter"
          },
          "D": {
            "item": "botania:shimmerrock"
          },
          "E": {
            "item": "botania:terrasteel_block"
          },
          "F": {
            "item": "botania:fabulous_pool"
          },
          "G": {
            "item": "botania:dreamwood"
          },
          "H": {
            "type": "forge:nbt",
            "item": "ironjetpacks:creative_jetpack",
            "count": 1,
            "nbt": "{Throttle:1.0d}"
          }
        },
        "result": {
          "item": "botania:creative_pool"
      }
      })
    e.custom({
        "type": "extendedcrafting:shaped_table",
        "pattern": [
          "ABBBCBBBA",
          "BDEEEEEDB",
          "BDFGFGFDB",
          "BDGHHHGDB",
          "CDFHIHFDC",
          "BDGHHHGDB",
          "BDFGFGFDB",
          "BDEEEEEDB",
          "ABBBCBBBA"
        ],
        "key": {
          "A": {
            "item": "mekanism:pellet_plutonium"
          },
          "B": {
            "item": "projecte:red_matter"
          },
          "C": {
            "item": "avaritia:infinity_catalyst"
          },
          "D": {
            "item": "mekanism:pellet_polonium"
          },
          "E": {
            "item": "appliedenergistics2:singularity"
          },
          "F": {
            "type": "forge:nbt",
            "item": "botania:mana_tablet",
            "count": 1,
            "nbt": "{mana:500000}"
          },
          "G": {
            "item": "powah:crystal_nitro"
          },
          "H": {
            "item": "avaritia:neutronium_ingot"
          },
          "I": {
            "item": "botania:creative_pool"
          }
        },
        "result": {
          "type": "forge:nbt",
          "item": "botania:mana_tablet",
          "count": 1,
          "nbt": "{mana:500000,creative:1b}"
        }
      })
    e.custom({
        "type": "extendedcrafting:shaped_table",
        "pattern": [
          "ABCCCCCBA",
          "BDEEEEEDB",
          "CEFGFGFEC",
          "CEGFHFGEC",
          "CEFHIHFEC",
          "CEGFHFGEC",
          "CEFGFGFEC",
          "BDEEEEEDB",
          "ABCCCCCBA"
        ],
        "key": {
          "A": {
            "item": "avaritia:infinity_catalyst"
          },
          "B": {
            "item": "avaritia:neutronium_ingot"
          },
          "C": {
            "item": "mekanism:pellet_plutonium"
          },
          "D": {
            "item": "projecte:red_matter"
          },
          "E": {
            "item": "extendedcrafting:ultimate_singularity"
          },
          "F": {
            "type": "forge:nbt",
            "item": "mekanism:ultimate_energy_cube",
            "count": 1,
            "nbt": "{mekData:{EnergyContainers:[{Container:0b,stored:\"256000000\"}]}}"
          },
          "G": {
            "item": "extendedcrafting:the_ultimate_catalyst"
          },
          "H": {
            "item": "create:shadow_steel"
          },
          "I": {
            "item": "kubejs:creative_steel_casing"
          }
        },
        "result": {
          "item": "mekanism:creative_energy_cube"
        }
      })  
    e.custom({
        "type": "extendedcrafting:shaped_table",
        "pattern": [
          "         ",
          "AAAAAAAAA",
          "ABBBBBBBA",
          "ABCCCCCBA",
          "ABCDEDCBA",
          "ABCCCCCBA",
          "ABBBBBBBA",
          "AAAAAAAAA",
          "         "
        ],
        "key": {
          "A": {
            "item": "powah:crystal_nitro"
          },
          "B": {
            "item": "create:shadow_steel"
          },
          "C": {
            "item": "mekanism:ultimate_chemical_tank"
          },
          "D": {
            "item": "mekanism:creative_energy_cube"
          },
          "E": {
            "item": "kubejs:creative_steel_casing"
          }
        },
        "result": {
          "item": "mekanism:creative_chemical_tank"
        }
      })
    e.custom({
        "type": "extendedcrafting:shaped_table",
        "pattern": [
          "ABCCCCCBA",
          "BDDEFEDDB",
          "CDGGGGGDC",
          "CEGHHHGEC",
          "CFGHIHGFC",
          "CEGHHHGEC",
          "CDGGGGGDC",
          "BDDEFEDDB",
          "ABCCCCCBA"
        ],
        "key": {
          "A": {
            "item": "mekanism:pellet_plutonium"
          },
          "B": {
            "item": "avaritia:infinity_catalyst"
          },
          "C": {
            "item": "avaritia:neutronium_ingot"
          },
          "D": {
            "item": "appliedenergistics2:singularity"
          },
          "E": {
            "item": "extendedcrafting:the_ultimate_catalyst"
          },
          "F": {
            "item": "projecte:red_matter"
          },
          "G": {
            "item": "mekanism:ultimate_fluid_tank"
          },
          "H": {
            "item": "powah:crystal_nitro"
          },
          "I": {
            "item": "mekanism:creative_chemical_tank"
          }
        },
        "result": {
          "item": "mekanism:creative_fluid_tank"
        }
      })
    e.custom({
        "type": "extendedcrafting:shaped_table",
        "pattern": [
          "ABCCCCCBA",
          "BDDDDDDDB",
          "CDEEEEEDC",
          "CDEFGFEDC",
          "CDEFHFEDC",
          "CDEFGFEDC",
          "CDEEEEEDC",
          "BDDDDDDDB",
          "ABCCCCCBA"
        ],
        "key": {
          "A": {
            "item": "avaritia:infinity_catalyst"
          },
          "B": {
            "item": "extendedcrafting:ultimate_singularity"
          },
          "C": {
            "item": "projecte:red_matter"
          },
          "D": {
            "item": "mysticalagradditions:creative_essence"
          },
          "E": {
            "item": "refinedstorageaddons:wireless_crafting_grid"
          },
          "F": {
            "item": "appliedenergistics2:wireless_terminal"
          },
          "G": {
            "item": "mekanism:pellet_polonium"
          },
          "H": {
            "item": "kubejs:creative_steel_casing"
          }
        },
        "result": {
          "item": "refinedstorageaddons:creative_wireless_crafting_grid"
        }
      })
    e.custom({
        "type": "extendedcrafting:shaped_table",
        "pattern": [
          "  ABBBA  ",
          " CDDDDDC ",
          "ADEEFEEDA",
          "BDEGHGEDB",
          "BDFHIHFDB",
          "BDEGHGEDB",
          "ADEEFEEDA",
          " CDDDDDC ",
          "  ABBBA  "
        ],
        "key": {
          "A": {
            "item": "mekanism:pellet_plutonium"
          },
          "B": {
            "item": "create:shadow_steel"
          },
          "C": {
            "item": "extendedcrafting:ultimate_singularity"
          },
          "D": {
            "item": "powah:crystal_nitro"
          },
          "E": {
            "item": "extendedcrafting:the_ultimate_catalyst"
          },
          "F": {
            "item": "mekanism:pellet_polonium"
          },
          "G": {
            "item": "mekanism:creative_energy_cube"
          },
          "H": {
            "item": "mysticalagradditions:creative_essence"
          },
          "I": {
            "item": "mekanism:creative_fluid_tank"
          }
        },
        "result": {
          "item": "cyclic:battery_infinite"
        }
      })
    e.custom({
        "type": "extendedcrafting:shaped_table",
        "pattern": [
          "ABBBBBBBA",
          "BCCCDCCCB",
          "BCEEEEECB",
          "BCEFGFECB",
          "BDEGHGEDB",
          "BCEFGFECB",
          "BCEEEEECB",
          "BCCCDCCCB",
          "ABBBBBBBA"
        ],
        "key": {
          "A": {
            "item": "extendedcrafting:ultimate_singularity"
          },
          "B": {
            "item": "create:shadow_steel"
          },
          "C": {
            "item": "appliedenergistics2:singularity"
          },
          "D": {
            "item": "avaritia:infinity_catalyst"
          },
          "E": {
            "item": "appliedenergistics2:dense_energy_cell"
          },
          "F": {
            "item": "mekanism:pellet_polonium"
          },
          "G": {
            "item": "extendedcrafting:the_ultimate_catalyst"
          },
          "H": {
            "item": "cyclic:battery_infinite"
          }
        },
        "result": {
          "item": "appliedenergistics2:creative_energy_cell"
        }
      })
    e.custom({
        "type": "extendedcrafting:shaped_table",
        "pattern": [
          "ABBBBBBBA",
          "BCCCDCCCB",
          "BCEEEEECB",
          "BCEFGFECB",
          "BDEGHGEDB",
          "BCEFGFECB",
          "BCEEEEECB",
          "BCCCDCCCB",
          "ABBBBBBBA"
        ],
        "key": {
          "A": {
            "item": "extendedcrafting:ultimate_singularity"
          },
          "B": {
            "item": "create:shadow_steel"
          },
          "C": {
            "item": "appliedenergistics2:singularity"
          },
          "D": {
            "item": "avaritia:infinity_catalyst"
          },
          "E": {
            "item": "refinedstorage:controller"
          },
          "F": {
            "item": "mekanism:pellet_polonium"
          },
          "G": {
            "item": "extendedcrafting:the_ultimate_catalyst"
          },
          "H": {
            "item": "cyclic:battery_infinite"
          }
        },
        "result": {
          "item": "refinedstorage:creative_controller"
        }
      })
    e.custom({
        "type": "extendedcrafting:shaped_table",
        "pattern": [
          "AAAAAAAAA",
          "ABCBDBCBA",
          "ACEDFDECA",
          "ABDFGFDBA",
          "ADFGHGFDA",
          "ABDFGFDBA",
          "ACEDFDECA",
          "ABCBDBCBA",
          "AAAAAAAAA"
        ],
        "key": {
          "A": {
            "item": "refinedstorage:storage_housing"
          },
          "B": {
            "item": "powah:crystal_nitro"
          },
          "C": {
            "item": "projecte:red_matter"
          },
          "D": {
            "item": "avaritia:infinity_catalyst"
          },
          "E": {
            "item": "mekanism:pellet_polonium"
          },
          "F": {
            "item": "extendedcrafting:ultimate_singularity"
          },
          "G": {
            "item": "extrastorage:storagepart_16384k"
          },
          "H": {
            "item": "storagedrawers:creative_storage_upgrade"
          }
        },
        "result": {
          "item": "refinedstorage:creative_storage_disk"
        }
      })
    e.custom({
        "type": "extendedcrafting:shaped_table",
        "pattern": [
          "AAAAAAAAA",
          "ABCBDBCBA",
          "ACEDFDECA",
          "ABDFGFDBA",
          "ADFGHGFDA",
          "ABDFGFDBA",
          "ACEDFDECA",
          "ABCBDBCBA",
          "AAAAAAAAA"
        ],
        "key": {
          "A": {
            "item": "appliedenergistics2:empty_storage_cell"
          },
          "B": {
            "item": "powah:crystal_nitro"
          },
          "C": {
            "item": "projecte:red_matter"
          },
          "D": {
            "item": "avaritia:infinity_catalyst"
          },
          "E": {
            "item": "mekanism:pellet_polonium"
          },
          "F": {
            "item": "extendedcrafting:ultimate_singularity"
          },
          "G": {
            "item": "ae2extras:16m_cell_component"
          },
          "H": {
            "item": "storagedrawers:creative_storage_upgrade"
          }
        },
        "result": {
          "item": "appliedenergistics2:creative_storage_cell"
        }
      })
    e.custom({
        "type": "extendedcrafting:shaped_table",
        "pattern": [
          "ABCCCCCBA",
          "BDEFFFEGB",
          "CEHHHHHEC",
          "CFHIIIHFC",
          "CFHIJIHFC",
          "CFHIIIHFC",
          "CEHHHHHEC",
          "BKEFFFELB",
          "ABCCCCCBA"
        ],
        "key": {
          "A": {
            "item": "extendedcrafting:the_ultimate_catalyst"
          },
          "B": {
            "item": "avaritia:neutronium_ingot"
          },
          "C": {
            "item": "projecte:red_matter"
          },
          "D": {
            "item": "appliedenergistics2:creative_energy_cell"
          },
          "E": {
            "item": "extendedcrafting:ultimate_singularity"
          },
          "F": {
            "item": "avaritia:infinity_ingot"
          },
          "G": {
            "item": "refinedstorage:creative_controller"
          },
          "H": {
            "item": "avaritia:infinity_catalyst"
          },
          "I": {
            "item": "minecraft:book"
          },
          "J": {
            "item": "appliedenergistics2:creative_storage_cell"
          },
          "K": {  
            "item": "refinedstorage:creative_storage_disk"
          },
          "L": {
            "item": "refinedstorageaddons:creative_wireless_crafting_grid"
          }
        },
        "result": {
          "item": "projecte:tome"
        }
      })
    e.custom({
        "type": "extendedcrafting:shaped_table",
        "pattern": [
          "AABCDCBAA",
          "AEEFGFEEA",
          "BEHHHHHEB",
          "CFHHHHHFC",
          "DGHIJKHGD",
          "CFHHHHHFC",
          "BEHHHHHEB",
          "AEEFGFEEA",
          "AABCDCBAA"
        ],
        "key": {
          "A": {
            "item": "powah:crystal_nitro"
          },
          "B": {
            "item": "mekanism:pellet_polonium"
          },
          "C": {
            "item": "extrastorage:storagepart_262144k_fluid"
          },
          "D": {
            "item": "storagedrawers:creative_storage_upgrade"
          },
          "E": {
            "item": "avaritia:infinity_catalyst"
          },
          "F": {
            "item": "avaritia:neutronium_ingot"
          },
          "G": {
            "item": "extendedcrafting:ultimate_singularity"
          },
          "H": {
            "item": "avaritia:infinity_ingot"
          },
          "I": {
            "item": "create:creative_crate"
          },
          "J": {
            "item": "kubejs:creative_steel_casing"
          },
          "K": {
            "item": "projecte:tome"
          }
        },
        "result": {
          "item": "storagedrawers:creative_vending_upgrade"
        }
      })
    e.custom({
        "type": "extendedcrafting:shaped_table",
        "pattern": [
          "AAAAAAAAA",
          "ABBBBBBBA",
          "ABAAAAABA",
          "ABACDEABA",
          "ABAFGHABA",
          "ABAIJKABA",
          "ABAAAAABA",
          "ABBBBBBBA",
          "AAAAAAAAA"
        ],
        "key": {
          "A": {
            "item": "storagedrawers:creative_vending_upgrade"
          },
          "B": {
            "item": "storagedrawers:creative_storage_upgrade"
          },
          "C": {
            "item": "create:creative_crate"
          },
          "D": {
            "item": "refinedstorage:creative_controller"
          },
          "E": {
            "item": "projecte:tome"
          },
          "F": {
            "type": "forge:nbt",
            "item": "ironjetpacks:creative_jetpack",
            "count": 1,
            "nbt": "{Throttle:1.0d}"
          },
          "G": {
            "item": "cyclic:battery_infinite"
          },
          "H": {
            "item": "appliedenergistics2:creative_storage_cell"
          },
          "I": {
            "item": "mekanism:creative_chemical_tank"
          },
          "J": {
            "item": "mekanism:creative_fluid_tank"
          },
          "K": {
            "item": "botania:creative_pool"
          }
        },
        "result": {
          "item": "cyclic:item_infinite"
        }
      })
});
       