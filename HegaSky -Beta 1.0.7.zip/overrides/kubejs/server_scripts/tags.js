events.listen('item.tags', event => {
    event.remove('twilightforest:portal/activator', '#forge:gems/diamond')
    event.add('twilightforest:portal/activator', 'bloodmagic:weakbloodshard')
})
