//priority: 3000

onEvent('recipes', event => {
    event.custom({
        "type": "bloodmagic:altar",
        "input": {
          "item": "cyclic:mason_cobble"
        },
        "output": {
          "item": "bloodmagic:blankslate"
        },
        "upgradeLevel": 0,
        "altarSyphon": 1000,
        "consumptionRate": 15,
        "drainRate": 1000
      })
      event.custom({
        "type": "bloodmagic:altar",
        "input": {
          "item": "minecraft:iron_ingot"
        },
        "output": {
          "item": "mekanism:ingot_steel"
        },
        "upgradeLevel": 1,
        "altarSyphon": 500,
        "consumptionRate": 15,
        "drainRate": 1000
      })
      event.custom({
        "type": "bloodmagic:altar",
        "input": {
          "item": "kubejs:cracked_reinforced_slate"
        },
        "output": {
          "item": "bloodmagic:infusedslate"
        },
        "upgradeLevel": 2,
        "altarSyphon": 7500,
        "consumptionRate": 15,
        "drainRate": 1000
      })
      event.custom({
        "type": "bloodmagic:altar",
        "input": {
          "item": "immersiveengineering:graphite_electrode"
        },
        "output": {
          "item": "bloodmagic:magicianbloodorb"
        },
        "upgradeLevel": 2,
        "altarSyphon": 25000,
        "consumptionRate": 15,
        "drainRate": 1000
      })
});
onEvent('recipes', (event) => {
  data = {
      recipes: [
          {
              inputs: ['powah:dielectric_casing', 'extendedcrafting:luminessence_block', 'mysticalagriculture:prudentium_ingot', 'bloodmagic:reinforcedslate', 'kubejs:advanced_steel_casing', 'bloodmagic:seersigil'],
              output: 'kubejs:elite_steel_casing',
              count: 1,
              syphon: 200,
              ticks: 200,
              orbLevel: 2,
              id: 'bloodmagic:alchemytable/create_elite_steel_casing'
          }
        ]
      };
  
      data.recipes.forEach((recipe) => {
          const re = event.recipes.bloodmagic
              .alchemytable(Item.of(recipe.output, recipe.count), recipe.inputs)
              .syphon(recipe.syphon)
              .ticks(recipe.ticks)
              .upgradeLevel(recipe.orbLevel);
          if (recipe.id) {
              re.id(recipe.id);
          }
      });
  });
