onEvent('recipes', (event) => {
    data = {
        recipes: [
            {
                inputs: ['botania:mana_diamond'],
                output: 'mekanism:enriched_diamond',
                count: 1,
            }
          ]
        };
    
        data.recipes.forEach((recipe) => {
            const re = event.recipes.mekanism
                .enriching(Item.of(recipe.output, recipe.count), recipe.inputs)
        });
    });




onEvent('recipes', (event) => {
    var data = {
        recipes: [
            {
                output: 'mekanism:dust_refined_obsidian',
                input: 'kubejs:blacked_dust',
                infusionInput: 'mekanism:diamond',
                infusionAmount: 10
            }
        ]
    };
    data.recipes.forEach((recipe) => {
        recipe.id
            ? event.recipes.mekanism
                  .metallurgic_infusing(recipe.output, recipe.input, recipe.infusionInput, recipe.infusionAmount)
                  .id(recipe.id)
            : event.recipes.mekanism.metallurgic_infusing(
                  recipe.output,
                  recipe.input,
                  recipe.infusionInput,
                  recipe.infusionAmount
              );
    });
});