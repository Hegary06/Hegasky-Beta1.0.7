onEvent(`recipes`, e => {
    e.shapeless(`kubejs:rotten_leather`, [`minecraft:rotten_flesh`, `minecraft:rotten_flesh`, `minecraft:rotten_flesh`]);
    e.smelting(Item.of(`minecraft:leather`), `kubejs:rotten_leather`).xp(0.5);
    e.recipes.minecraft.smoking(Item.of(`minecraft:leather`), `kubejs:rotten_leather`).xp(0.5);
    e.smelting(Item.of(`kubejs:ingot_hega`), `kubejs:chunk_hega`).xp(0.5);
    e.smelting(Item.of(`kubejs:ingot_gera`), `kubejs:chunk_gera`).xp(0.5);
    e.smelting(Item.of(`tconstruct:cobalt_ingot`), `kubejs:chunk_cobalt`).xp(0.5);    
});