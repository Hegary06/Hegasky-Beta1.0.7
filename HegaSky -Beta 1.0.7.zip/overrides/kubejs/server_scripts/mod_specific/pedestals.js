onEvent(`recipes`, e => {
    var coinRF = [
      `import`,
      `export`,
      `crusher`,
      `smelter`,
      `sawmill`,
      `quarry`,
      `quarryb`
    ];
    var coinXP = [
      `dropper`,
      `magnet`
    ];
    const pedestalCrush = (result, count, ingredient) => {
      e.custom({
        type: `pedestals:pedestal_crushing`,
        ingredient: Ingredient.of(ingredient).toJson(),
        result: Item.of(result, count).toResultJson(),
      });
    };
  
    const pedestalSaw = (result, count, ingredient) => {
      e.custom({
        type: `pedestals:pedestal_sawing`,
        ingredient: Ingredient.of(ingredient).toJson(),
        result: Item.of(result, count).toResultJson(),
      });
    };
    const cobbleGen = (result, ingredient) => {
      e.custom({
        type: `pedestals:pedestal_cobblegen`,
        ingredient: Ingredient.of(ingredient).toJson(),
        result: Item.of(result).toResultJson()
      });
    };
    const cobbleGenSilk = (result, ingredient) => {
      e.custom({
        type: `pedestals:pedestal_cobblegensilk`,
        ingredient: Ingredient.of(ingredient).toJson(),
        result: Item.of(result).toResultJson()
      });
    };
    cobbleGen(`mysticalagriculture:soulstone_cobble`, `mysticalagriculture:soulium_block`);
    cobbleGenSilk(`mysticalagriculture:soulstone`, `mysticalagriculture:soulium_block`);
    cobbleGen(`enviromats:marble`, `enviromats:marble_brick`);
    e.remove({
      id: `appliedenergistics2:grinder/flour`
    });
    var pedSawRemove = [
      `#minecraft:signs`,
      `#minecraft:wooden_stairs`,
      `#minecraft:wooden_slabs`,
      `#minecraft:wooden_trapdoors`,
      `#minecraft:wooden_pressure_plates`,
      `minecraft:stick`,
    ];
    pedSawRemove.forEach(pedsr => {
      e.remove({
        output: pedsr,
        type: `pedestals:pedestal_sawing`
      });
    });
    pedestalCrush(`appliedenergistics2:fluix_dust`, 1, `appliedenergistics2:fluix_crystal`);
    pedestalCrush(`appliedenergistics2:certus_quartz_dust`, 1, `#forge:gems/certus_quartz`);
    pedestalCrush(`thermal:quartz_dust`, 1, `#forge:gems/quartz`);
    pedestalCrush(`mekanism:dust_fluorite`, 1, `#forge:gems/fluorite`);
    pedestalSaw(`thermal:sawdust`, 1, `#forge:rods/wooden`);
    pedestalSaw(`minecraft:stick`, 4, `#minecraft:planks`);
    pedestalSaw(`minecraft:stick`, 2, `#minecraft:wooden_slabs`);
    
    
    // Remove Fluid XP Conversiond defaults.
    e.remove({id: 'pedestals:pedestal_fluid_to_xp/if_essence_to_xp'});
    e.remove({id: 'pedestals:pedestal_fluid_to_xp/lava_to_xp'});
    
  
    // With default settings, cyclic appears to use a 91/1 ratio here.
    // This already created a kind of fluid xp loop which is very hard
    // to fix, so we simply do our best to not make it worse.
    const expMappings = [
      ['industrialforegoing:essence_bucket', 91],
      ['cyclic:xpjuice_bucket', 91],
      ['bloodmagic:life_essence_bucket', 60], // Some automation can make this a double tap, so it's not 1:1 with xp.
      ['minecraft:lava_bucket', 5], // Since lava is trivially infinite, make it even less profitable.
    ]
  
    const registerPedestalsFluidConversion = function(tup) {
      const id  = tup[0];
      const amt = tup[1];
  
      if( id != null && amt != null ) {
        e.custom({
          type: 'pedestals:pedestal_fluid_to_xp',
          ingredient: {
            item: id
          },
          result: {
            item: "minecraft:experience_bottle",
            count: amt
          },
        });
      } else {
        console.warn('Skipped invalid recipe for Pedestals fluid conversion')
      }
    };
  
    expMappings.forEach(registerPedestalsFluidConversion);
  });
  
  // Limit Break Pedestals.
  onEvent('item.tags', event => {
    event.get('pedestals:enchant_limits/advanced_blacklist').remove('pedestals:coin/xpanvil')
  });
    
  