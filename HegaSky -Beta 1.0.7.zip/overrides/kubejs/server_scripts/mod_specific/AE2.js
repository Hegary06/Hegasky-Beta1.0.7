onEvent('recipes', event => {
    event.custom({
      "type": "appliedenergistics2:inscriber",
      "mode": "inscribe",
      "result": {
        "item": "refinedstorage:machine_casing"
      },
      "ingredients": {
        "top": {
          "item": "refinedstorage:quartz_enriched_iron_block"
        },
        "middle": {
          "item": "compressium:stone_2"
        },
        "bottom": {
          "item": "minecraft:redstone_block"
        }
      }
    })
  })
  