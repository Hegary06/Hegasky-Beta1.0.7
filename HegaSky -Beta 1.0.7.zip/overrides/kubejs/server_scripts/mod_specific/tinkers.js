events.listen('recipes', event => {

event.custom({"type": "tconstruct:alloy","inputs": [{"name": "tconstruct:molten_iron","amount": 144},{"name": "kubejs:molten_coal","amount": 432}],
"result": {"fluid": "tconstruct:molten_steel","amount": 144},"temperature": 800})

event.custom({"type": "tconstruct:casting_table","cast": {"item": "tconstruct:ingot_cast"},"fluid": {"name": "tconstruct:molten_steel","amount": 144},"result": "mekanism:ingot_steel","cooling_time": 50})

event.custom({"type": "tconstruct:melting","ingredient": {"tag": "minecraft:coals"},"result": {"fluid": "kubejs:molten_coal","amount": 144},"temperature": 200,"time": 10})

event.custom({"type": "tconstruct:casting_table","cast": {"item": "tconstruct:gem_cast"},"fluid": {"name": "kubejs:molten_coal","amount": 144},"result": "minecraft:coal","cooling_time": 20})
  
})