//priority: 9999
settings.logAddedRecipes = true;
settings.logRemovedRecipes = true;
settings.logSkippedRecipes = true;
settings.logErroringRecipes = true;