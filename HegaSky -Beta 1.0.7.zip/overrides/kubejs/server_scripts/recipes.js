onEvent(`recipes`, e => {
    var mekCrush = e.recipes.mekanism.crushing;
    var mekEnrich = e.recipes.mekanism.enriching;

    const energize = (ingredient, result, rCount, power) => {
        e.recipes.powah.energizing({
            ingredients: ingredient,
            energy: power,
            result: {
                item: result,
                count: rCount
            }
        });
    };

    //Misc recipes
    e.shaped(`minecraft:elytra`, [
        `msm`,
        `mbm`,
        `m m`
    ], {
        m: `minecraft:phantom_membrane`,
        s: `quark:dragon_scale`,
        b: `ironjetpacks:strap`
    });
    e.shapeless(Item.of(`appliedenergistics2:fluix_covered_cable`, 4), `appliedenergistics2:fluix_covered_dense_cable`);
    e.shapeless(Item.of(`appliedenergistics2:fluix_smart_cable`, 4), `appliedenergistics2:fluix_smart_dense_cable`);
    e.shaped(`appliedenergistics2:fluix_smart_dense_cable`, [
        `AA`,
        `AA`
    ], {
        A: `appliedenergistics2:fluix_smart_cable`
    });
    e.shaped(`appliedenergistics2:fluix_covered_dense_cable`, [
        `AA`,
        `AA`
    ], {
        A: `appliedenergistics2:fluix_covered_cable`
    });
    e.smelting(Item.of(`appliedenergistics2:certus_quartz_crystal`), `#forge:ores/certus_quartz`).xp(1);
    e.smelting(Item.of(`minecraft:glass`), `#forge:sand`).xp(0.1);
    e.shapeless(Item.of(`minecraft:clay_ball`, 4), `#forge:storage_blocks/clay`);
    e.shapeless(Item.of(`minecraft:quartz`, 4), `#forge:storage_blocks/quartz`);
    e.shapeless(Item.of(`minecraft:glowstone_dust`, 4), `#forge:glowstone`);
    e.shaped(`appliedenergistics2:silicon_press`, [
        `EEE`,
        `EAE`,
        `EEE`
    ], {
        E: `mysticalagriculture:iron_essence`,
        A: `mysticalagriculture:silicon_essence`
    });
    e.shaped(`appliedenergistics2:calculation_processor_press`, [
        `EEE`,
        `EAE`,
        `EEE`
    ], {
        E: `mysticalagriculture:iron_essence`,
        A: `mysticalagriculture:certus_quartz_essence`
    });
    e.shaped(`appliedenergistics2:engineering_processor_press`, [
        `EEE`,
        `EAE`,
        `EEE`
    ], {
        E: `mysticalagriculture:iron_essence`,
        A: `mysticalagriculture:diamond_essence`
    });
    e.shaped(`appliedenergistics2:logic_processor_press`, [
        `EEE`,
        `EAE`,
        `EEE`
    ], {
        E: `mysticalagriculture:iron_essence`,
        A: `mysticalagriculture:gold_essence`
    });
    e.shaped(`minecraft:hopper`, [
        `ILI`,
        `ILI`,
        ` I `
    ], {
        L: `#minecraft:logs`,
        I: `#forge:ingots/iron`
    });
    e.shaped(Item.of(`minecraft:stick`, 16), [
        `L`,
        `L`
    ], {
        L: `#minecraft:logs`
    });
    e.custom({
    type: `industrialforegoing:dissolution_chamber`,
        input: [
            Ingredient.of(`#minecraft:planks`).toJson(),
            Ingredient.of(`#minecraft:planks`).toJson(),
            Ingredient.of(`#minecraft:planks`).toJson(),
            Ingredient.of(`#minecraft:planks`).toJson(),
            Ingredient.of(`#minecraft:planks`).toJson(),
            Ingredient.of(`#minecraft:planks`).toJson(),
            Ingredient.of(`#minecraft:planks`).toJson(),
            Ingredient.of(`#minecraft:planks`).toJson()
        ],
        inputFluid: `{FluidName:\"immersiveengineering:creosote\",Amount:1000}`,
        processingTime: 1,
        output: Item.of(`immersiveengineering:treated_wood_horizontal`, 8).toResultJson()
    });
    e.custom({
    type: `industrialforegoing:dissolution_chamber`,
        input: [
            Ingredient.of(`industrialforegoing:plastic`).toJson(),
            Ingredient.of(`industrialforegoing:machine_frame_simple`).toJson(),
            Ingredient.of(`industrialforegoing:plastic`).toJson(),
            Ingredient.of(`minecraft:netherite_scrap`).toJson(),
            Ingredient.of(`minecraft:netherite_scrap`).toJson(),
            Ingredient.of(`botania:elementium_ingot`).toJson(),
            Ingredient.of(`thermal:diamond_gear`).toJson(),
            Ingredient.of(`botania:elementium_ingot`).toJson()
        ],
        inputFluid: `{FluidName:\"industrialforegoing:pink_slime\",Amount:500}`,
        processingTime: 1,
        output: Item.of(`industrialforegoing:machine_frame_advanced`, 1).toResultJson()
    });

    mekCrush(Item.of(`minecraft:blaze_powder`, 4), `#forge:rods/blaze`);
    mekCrush(Item.of(`minecraft:quartz`, 4), `#forge:storage_blocks/quartz`);
    mekEnrich(Item.of(`minecraft:blaze_rod`), [Item.of(`minecraft:blaze_powder`, 6)]);
    mekEnrich(Item.of(`powah:uraninite`, 2), `powah:uraninite_ore_poor`);
    mekEnrich(Item.of(`powah:uraninite`, 4), `powah:uraninite_ore`);
    mekEnrich(Item.of(`powah:uraninite`, 8), `powah:uraninite_ore_dense`);

    //Extrastorage fixes
    e.shaped(`extrastorage:iron_crafter`, [
        `B B`,
        `PCP`,
        `B B`
    ], {
        B: `#forge:storage_blocks/iron`,
        P: `refinedstorage:improved_processor`,
        C: `#refinedstorage:crafter`
    });
    e.shaped(`extrastorage:gold_crafter`, [
        `B B`,
        `PCP`,
        `B B`
    ], {
        B: `#forge:storage_blocks/gold`,
        P: `refinedstorage:advanced_processor`,
        C: `extrastorage:iron_crafter`
    });
    e.shaped(`extrastorage:diamond_crafter`, [
        `B B`,
        `PCP`,
        `B B`
    ], {
        B: `#forge:storage_blocks/diamond`,
        P: `extradisks:withering_processor`,
        C: `extrastorage:gold_crafter`
    });
    e.shaped(`extrastorage:netherite_crafter`, [
        `BBB`,
        `PCP`,
        `BBB`
    ], {
        B: `#forge:ingots/netherite`,
        P: `extradisks:withering_processor`,
        C: `extrastorage:diamond_crafter`
    });

    //Cable Tiers changes
    var caTypes = [
        `importer`,
        `exporter`,
        `constructor`,
        `destructor`
    ];
    const caTier = (tier, corners, processor, cables) => {
        caTypes.forEach(caType => {
            e.shaped(`cabletiers:${tier}_${caType}`, [
                `a a`,
                `bcb`,
                `a a`
            ], {
                a: corners,
                b: processor,
                c: `${cables}${caType}`
            });
        });
    };           
    caTier(`elite`, `#forge:storage_blocks/iron`, `refinedstorage:improved_processor`, `refinedstorage:`);
    caTier(`ultra`, `#forge:storage_blocks/diamond`, `refinedstorage:advanced_processor`, `cabletiers:elite_`);
    caTier(`creative`, `#forge:ingots/netherite`, `extradisks:withering_processor`, `cabletiers:ultra_`);

    e.shaped(`botania:apothecary_default`, [
        `BAB`,
        ` C `,
        `DDD`
    ], {
        A: `#botania:petals`,
        B: `minecraft:cobblestone_slab`,
        C: `kubejs:elite_steel_casing`,
        D: `#forge:cobblestone`
    });
    e.shaped(`industrialforegoing:machine_frame_pity`, [
        `BAB`,
        `ACA`,
        `BAB`
    ], {
        A: `minecraft:iron_ingot`,
        B: `#minecraft:logs`,
        C: `mekanism:elite_control_circuit`,
    });
    e.shaped(`extendedcrafting:advanced_table`, [
        `BAB`,
        `DCD`,
        `BEB`
    ], {
        A: `extendedcrafting:advanced_catalyst`,
        B: `extendedcrafting:advanced_component`,
        C: `minecraft:gold_block`,
        D: `extendedcrafting:basic_table`,
        E: `industrialforegoing:machine_frame_simple`,
    });
    e.shaped(`immersiveengineering:hammer`, [
        ` AB`,
        ` CA`,
        `C  `
    ], {
        A: `industrialforegoing:plastic`,
        B: `minecraft:string`,
        C: `minecraft:stick`,   
    });
    e.shaped(`appliedenergistics2:inscriber`, [
        `ABA`,
        `C D`,
        `ABA`
    ], {
        A: `mekanism:ingot_steel`,
        B: `minecraft:sticky_piston`, 
        C: `bloodmagic:weakbloodshard`, 
        D: `kubejs:elite_steel_casing`, 
    });
    e.shaped(`appliedenergistics2:controller`, [
        `ABA`,
        `CDC`,
        `ABA`
    ], {
        A: `appliedenergistics2:smooth_sky_stone_block`,
        B: `appliedenergistics2:purified_fluix_crystal`, 
        C: `appliedenergistics2:engineering_processor`, 
        D: `refinedstorage:machine_casing`, 
    });
    e.shaped(`appliedenergistics2:semi_dark_monitor`, [
        ` BA`,
        `CED`,
        ` BA`
    ], {
        A: `appliedenergistics2:quartz_glass`,
        B: `minecraft:glowstone_dust`, 
        C: `minecraft:iron_ingot`, 
        D: `refinedstorage:machine_casing`, 
        E: `minecraft:redstone`,
    });
    e.shaped(`appliedenergistics2:drive`, [
        `ABA`,
        `CDC`,
        `ABA`
    ], {
        A: `minecraft:iron_ingot`,
        B: `appliedenergistics2:engineering_processor`, 
        C: `appliedenergistics2:fluix_glass_cable`, 
        D: `refinedstorage:machine_casing`, 
    });
    e.shaped(`botania:alfheim_portal`, [
        `ABA`,
        `ACA`,
        `ABA`
    ], {
        A: `botania:livingwood`,
        B: `botania:terrasteel_nugget`, 
        C: `kubejs:ultimate_steel_casing`, 
    });
    e.shaped(`extendedcrafting:elite_table`, [
        `BAB`,
        `DCD`,
        `BEB`
    ], {
        A: `extendedcrafting:elite_catalyst`,
        B: `extendedcrafting:elite_component`,
        C: `minecraft:diamond_block`,
        D: `extendedcrafting:advanced_table`,
        E: `industrialforegoing:machine_frame_supreme`,
    });
    e.shaped(item.of(`bloodmagic:largebloodstonebrick`, 8), [
        `BAB`,
        `ACA`,
        `BAB`
    ], {
        A: `bloodmagic:weakbloodshard`,
        B: `minecraft:stone`,
        C: `mekanism:ultimate_control_circuit`,
    });
    e.shaped(`appliedenergistics2:interface`, [
        `BAB`,
        `EDC`,
        `BAB`
    ], {
        A: `#forge:glass`,
        B: `minecraft:iron_ingot`,
        C: `appliedenergistics2:formation_core`,
        D: `bloodmagic:masterbloodorb`,
        E: `appliedenergistics2:annihilation_core`,
    });
    e.shaped(`refinedstorage:crafter`, [
        `BCB`,
        `ADA`,
        `BCB`
    ], {
        A: `bloodmagic:demonslate`,
        B: `refinedstorage:quartz_enriched_iron`,
        C: `refinedstorage:advanced_processor`,
        D: `refinedstorage:machine_casing`,
    });
    e.shaped(`extendedcrafting:ultimate_table`, [
        `BAB`,
        `DCD`,
        `BEB`
    ], {
        A: `extendedcrafting:ultimate_catalyst`,
        B: `extendedcrafting:ultimate_component`,
        C: `minecraft:emerald_block`,
        D: `extendedcrafting:elite_table`,
        E: `kubejs:legendary_steel_casing`,
    });
    e.shaped(`projecte:condenser_mk1`, [
        `BAB`,
        `ACA`,
        `BAB`
    ], {
        A: `projecte:dark_matter`,
        B: `minecraft:obsidian`,
        C: `projecte:alchemical_chest`,
    });
    e.shaped(`mysticalagradditions:creative_essence`, [
        ` A `,
        `ABA`,
        ` A `
    ], {
        A: `mysticalagradditions:insanium_gemstone_block`,
        B: `mysticalagriculture:master_infusion_crystal`,
    });
    e.shaped(`kubejs:cracked_reinforced_slate`, [
        ` A `,
        ` B `,
        `   `
    ], {
        A: `immersiveengineering:hammer`,
        B: `bloodmagic:reinforcedslate`, 
    });
    e.shaped(`cobblefordays:tier_2`, [
        `AAA`,
        `DCB`,
        `AAA`
    ], {
        A: `minecraft:cobblestone`,
        B: `minecraft:lava_bucket`,
        C: `cobblefordays:tier_1`,
        D: `minecraft:water_bucket`,
    });
    e.shaped(`cobblefordays:tier_3`, [
        `AAA`,
        `DCB`,
        `AAA`
    ], {
        A: `minecraft:iron_ingot`,
        B: `minecraft:lava_bucket`,
        C: `cobblefordays:tier_2`,
        D: `minecraft:water_bucket`,
    });
    e.shaped(`cobblefordays:tier_4`, [
        `AAA`,
        `DCB`,
        `AAA`
    ], {
        A: `minecraft:gold_ingot`,
        B: `minecraft:lava_bucket`,
        C: `cobblefordays:tier_3`,
        D: `minecraft:water_bucket`,
    });
    e.shaped(`cobblefordays:tier_5`, [
        `AAA`,
        `DCB`,
        `AAA`
    ], {
        A: `minecraft:diamond`,
        B: `minecraft:lava_bucket`,
        C: `cobblefordays:tier_4`,
        D: `minecraft:water_bucket`,
    });
})