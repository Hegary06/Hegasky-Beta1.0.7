//priority: 999
onEvent(`recipes`, e => {
    var idRemove = [

        `botania:conversions/blazeblock_deconstruct`,
        `pedestals:pedestal_crushing/dustnethergold`,
        `exnihilosequentia:heat/ens_wall_torch`,
        `exnihilosequentia:heat/ens_fire`,
        `exnihilosequentia:heat/ens_magma_block`,
        `exnihilosequentia:heat/ens_lava`,
        `excompressum:hammer/logs`,
    ];
    idRemove.forEach(iR => {
        e.remove({
            id: iR
        });
    });
    //Recipe via output
    e.remove({
        output: [
            `appliedenergistics2:silicon`,
            `cyclic:uncrafter`,
            `cyclic:tile_transporter_empty`,
            /cyclic:.*_pipe/,
            `cyclic:cable_wrench`,
            `cyclic:sleeping_mat`,
            `extradisks:infinite_fluid_storage_part`,
            `extradisks:infinite_storage_part`,
            `darkutils:ender_hopper`,
            `excompressum:compressed_cobblestone`,
            `excompressum:compressed_gravel`,
            `excompressum:compressed_sand`,
            `excompressum:compressed_dirt`,
            `excompressum:compressed_soul_sand`,
            `excompressum:compressed_netherrack`,
            `excompressum:compressed_end_stone`,
            `excompressum:compressed_diorite`,
            `excompressum:compressed_granite`,
            `excompressum:compressed_andesite`,
            /excompressum:.*_crucible/,
            `pedestals:dustflour`,
        ]
    });
});  
events.listen('recipes', e => {
    e.remove({
      output: [
        'botania:apothecary_default',
        'matc:inferium_crystal',
        'immersiveengineering:treated_wood_horizontal',
        'rftoolsbase:machine_frame',
        'bloodmagic:altar',
        'extendedcrafting:black_iron_ingot',
        'creativecrafter:creative_crafter',
        'ironfurnaces:netherite_furnace',
        'mekanism:metallurgic_infuser',
        'industrialforegoing:machine_frame_pity',
        'extendedcrafting:advanced_table',
        'immersiveengineering:hammer',
        'immersiveengineering:cokebrick',
        'appliedenergistics2:inscriber',        
        'refinedstorage:machine_casing',        
        'appliedenergistics2:drive',
        'appliedenergistics2:semi_dark_monitor',
        'appliedenergistics2:controller',
        'botania:alfheim_portal',
        'extendedcrafting:elite_table',
        'bloodmagic:largebloodstonebrick',
        'appliedenergistics2:interface',
        'matc:prudentium_crystal',
        'refinedstorage:crafter',
        'matc:tertium_crystal',
        'extendedcrafting:ultimate_table',
        'matc:imperium_crystal',
        'extendedcrafting:compressor',
        'projecte:philosophers_stone',
        'projecte:transmutation_table',
        'projecte:condenser_mk1',
        'twilightforest:uncrafting_table',
        'usrg:redstonegenerator',
        'cobblefordays:tier_2',
        'cobblefordays:tier_3',
        'cobblefordays:tier_4',
        'cobblefordays:tier_5',
    ]
    
    })
})
onEvent('recipes', event => {
    event.remove({id: 'bloodmagic:altar/slate'})
    event.remove({id: 'mekanism:infusion_conversion/diamond/from_dust'})
    event.remove({id: 'mekanism:enriching/enriched/diamond'})
    event.remove({id: 'bloodmagic:altar/imbuedslate'})
    event.remove({id: 'bloodmagic:altar/magicianbloodorb'})
    event.remove({id: 'industrialforegoing:dissolution_chamber/advanced_machine_frame'})
    event.remove({id: 'mekanism:processing/refined_obsidian/dust/from_obsidian_dust'})
    event.remove({id: 'mysticalagriculture:mushroom_seeds'})
    event.remove({id: 'exnihilotinkers:tinkers/casting_ichor_slime_dirt[tconstruct:casting_basin]'})





























})