  events.listen('item.registry', function(e) {
    e.create('piece_hega').displayName('Hega Ore Piece');
    e.create('chunk_hega').displayName('Hega Ore Chunk');
    e.create('ingot_hega').displayName('Hega ingot');
    e.create('piece_gera').displayName('Gera Ore Piece');
    e.create('chunk_gera').displayName('Gera Ore Chunk'); 
    e.create('ingot_gera').displayName('Gera ingot');
    e.create('rotten_leather').displayName('Rotten Leather')
    e.create('chunk_cobalt').displayName('Cobalt Ore Chunk')
    e.create('piece_cobalt').displayName('Cobalt Ore Piece')    
    e.create('blacked_dust').displayName('Blacked Dust') 
    e.create('cracked_reinforced_slate').displayName('Cracked Reinforced Slate') 
  })

  events.listen('block.registry', function(e) { 
	  e.create('aquamarine_block').displayName('Aquamarine Block').material('rock').hardness(2).lightLevel(1)
	  e.create('advanced_steel_casing').displayName('Advanced Steel Casing').material('ice').hardness(1.2)
	  e.create('elite_steel_casing').displayName('Elite Steel Casing').material('ice').hardness(1.2)
	  e.create('ultimate_steel_casing').displayName('Ultimate Steel Casing').material('ice').hardness(1.2)
    e.create('legendary_steel_casing').displayName('Legendary Steel Casing').material('ice').hardness(1.2)
    e.create('creative_steel_casing').displayName('Creative Steel Casing').material('ice').hardness(1.2).glow(true)  
  })
  
  events.listen('fluid.registry', function(e) { 
    e.create('molten_coal').textureThick(0x7F2300).displayName('Molten Coal').bucketColor(0x7F2300)
  })